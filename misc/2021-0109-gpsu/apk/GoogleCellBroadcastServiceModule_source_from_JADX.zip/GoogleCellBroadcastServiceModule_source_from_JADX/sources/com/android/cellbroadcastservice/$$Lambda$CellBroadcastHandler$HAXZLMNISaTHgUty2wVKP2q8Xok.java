package com.android.cellbroadcastservice;

import java.util.function.Function;

/* renamed from: com.android.cellbroadcastservice.-$$Lambda$CellBroadcastHandler$HAXZLMNISaTHgUty2wVKP2q8Xok  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$CellBroadcastHandler$HAXZLMNISaTHgUty2wVKP2q8Xok implements Function {
    public static final /* synthetic */ $$Lambda$CellBroadcastHandler$HAXZLMNISaTHgUty2wVKP2q8Xok INSTANCE = new $$Lambda$CellBroadcastHandler$HAXZLMNISaTHgUty2wVKP2q8Xok();

    private /* synthetic */ $$Lambda$CellBroadcastHandler$HAXZLMNISaTHgUty2wVKP2q8Xok() {
    }

    public final Object apply(Object obj) {
        return CellBroadcastHandler.lambda$new$0((Integer[]) obj);
    }
}
