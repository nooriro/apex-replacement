package androidx.appcompat;

public final class R$bool {
    public static final int abc_action_bar_embed_tabs = 2130903040;
}
