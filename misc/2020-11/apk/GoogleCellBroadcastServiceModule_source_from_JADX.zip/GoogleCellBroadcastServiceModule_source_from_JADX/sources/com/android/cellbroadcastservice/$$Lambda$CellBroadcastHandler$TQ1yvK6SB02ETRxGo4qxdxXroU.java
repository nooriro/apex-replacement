package com.android.cellbroadcastservice;

import android.content.pm.ResolveInfo;
import java.util.function.Predicate;

/* renamed from: com.android.cellbroadcastservice.-$$Lambda$CellBroadcastHandler$TQ1yvK6SB02ETRxGo4qxdxX-roU  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$CellBroadcastHandler$TQ1yvK6SB02ETRxGo4qxdxXroU implements Predicate {
    public static final /* synthetic */ $$Lambda$CellBroadcastHandler$TQ1yvK6SB02ETRxGo4qxdxXroU INSTANCE = new $$Lambda$CellBroadcastHandler$TQ1yvK6SB02ETRxGo4qxdxXroU();

    private /* synthetic */ $$Lambda$CellBroadcastHandler$TQ1yvK6SB02ETRxGo4qxdxXroU() {
    }

    public final boolean test(Object obj) {
        return CellBroadcastHandler.lambda$getDefaultCBRPackageName$3((ResolveInfo) obj);
    }
}
