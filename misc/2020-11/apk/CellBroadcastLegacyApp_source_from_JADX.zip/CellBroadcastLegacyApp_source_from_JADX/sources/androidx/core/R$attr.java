package androidx.core;

public final class R$attr {
    public static final int alpha = 2130837545;
}
