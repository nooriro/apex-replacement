package androidx.core.internal.view;

import android.view.Menu;

public interface SupportMenu extends Menu {
}
