package androidx.core.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    public void onAnimationCancel(View view) {
    }

    public void onAnimationStart(View view) {
    }
}
