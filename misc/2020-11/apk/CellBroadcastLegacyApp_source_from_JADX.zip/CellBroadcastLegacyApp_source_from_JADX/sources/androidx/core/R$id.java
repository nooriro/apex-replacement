package androidx.core;

public final class R$id {
    public static final int accessibility_action_clickable_span = 2131165190;
    public static final int tag_accessibility_actions = 2131165327;
    public static final int tag_accessibility_clickable_spans = 2131165328;
    public static final int tag_accessibility_heading = 2131165329;
    public static final int tag_accessibility_pane_title = 2131165330;
    public static final int tag_screen_reader_focusable = 2131165331;
    public static final int tag_state_description = 2131165332;
    public static final int tag_transition_group = 2131165333;
    public static final int tag_unhandled_key_event_manager = 2131165334;
    public static final int tag_unhandled_key_listeners = 2131165335;
}
