package androidx.lifecycle.runtime;

public final class R$id {
    public static final int view_tree_lifecycle_owner = 2131165350;
}
