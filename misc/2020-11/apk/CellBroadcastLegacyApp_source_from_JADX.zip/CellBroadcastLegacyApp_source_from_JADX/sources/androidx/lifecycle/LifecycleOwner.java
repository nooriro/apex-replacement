package androidx.lifecycle;

public interface LifecycleOwner {
    Lifecycle getLifecycle();
}
