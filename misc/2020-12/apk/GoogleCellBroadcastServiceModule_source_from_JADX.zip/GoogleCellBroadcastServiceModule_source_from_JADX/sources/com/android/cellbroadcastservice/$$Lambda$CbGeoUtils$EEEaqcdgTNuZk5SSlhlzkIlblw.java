package com.android.cellbroadcastservice;

import java.util.function.Predicate;

/* renamed from: com.android.cellbroadcastservice.-$$Lambda$CbGeoUtils$EEEaqcdgTNuZk5SSl-hlzkIlblw  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$CbGeoUtils$EEEaqcdgTNuZk5SSlhlzkIlblw implements Predicate {
    public static final /* synthetic */ $$Lambda$CbGeoUtils$EEEaqcdgTNuZk5SSlhlzkIlblw INSTANCE = new $$Lambda$CbGeoUtils$EEEaqcdgTNuZk5SSlhlzkIlblw();

    private /* synthetic */ $$Lambda$CbGeoUtils$EEEaqcdgTNuZk5SSlhlzkIlblw() {
    }

    public final boolean test(Object obj) {
        return CbGeoUtils.lambda$encodeGeometriesToString$1((String) obj);
    }
}
