package com.android.cellbroadcastservice;

import android.util.Pair;
import java.util.Objects;
import java.util.function.Predicate;

/* renamed from: com.android.cellbroadcastservice.-$$Lambda$G2EHUJbGSxlOUsxs1bcY-92HMtE  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$G2EHUJbGSxlOUsxs1bcY92HMtE implements Predicate {
    public static final /* synthetic */ $$Lambda$G2EHUJbGSxlOUsxs1bcY92HMtE INSTANCE = new $$Lambda$G2EHUJbGSxlOUsxs1bcY92HMtE();

    private /* synthetic */ $$Lambda$G2EHUJbGSxlOUsxs1bcY92HMtE() {
    }

    public final boolean test(Object obj) {
        return Objects.nonNull((Pair) obj);
    }
}
