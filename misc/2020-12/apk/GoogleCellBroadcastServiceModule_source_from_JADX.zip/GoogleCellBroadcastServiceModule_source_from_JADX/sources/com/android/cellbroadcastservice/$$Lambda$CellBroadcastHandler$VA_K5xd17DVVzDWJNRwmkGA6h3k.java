package com.android.cellbroadcastservice;

import java.util.function.Function;

/* renamed from: com.android.cellbroadcastservice.-$$Lambda$CellBroadcastHandler$VA_K5xd17DVVzDWJNRwmkGA6h3k  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$CellBroadcastHandler$VA_K5xd17DVVzDWJNRwmkGA6h3k implements Function {
    public static final /* synthetic */ $$Lambda$CellBroadcastHandler$VA_K5xd17DVVzDWJNRwmkGA6h3k INSTANCE = new $$Lambda$CellBroadcastHandler$VA_K5xd17DVVzDWJNRwmkGA6h3k();

    private /* synthetic */ $$Lambda$CellBroadcastHandler$VA_K5xd17DVVzDWJNRwmkGA6h3k() {
    }

    public final Object apply(Object obj) {
        return CellBroadcastHandler.lambda$new$1((Integer[]) obj);
    }
}
