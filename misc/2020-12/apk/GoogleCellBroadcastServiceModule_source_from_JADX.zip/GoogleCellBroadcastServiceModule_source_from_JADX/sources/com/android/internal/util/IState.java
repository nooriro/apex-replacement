package com.android.internal.util;

import android.compat.annotation.UnsupportedAppUsage;

public interface IState {
    @UnsupportedAppUsage
    String getName();
}
