package androidx.core.view;

public interface NestedScrollingChild {
    void stopNestedScroll();
}
