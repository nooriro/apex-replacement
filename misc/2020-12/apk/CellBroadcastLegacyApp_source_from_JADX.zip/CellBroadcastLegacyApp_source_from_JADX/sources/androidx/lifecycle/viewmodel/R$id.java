package androidx.lifecycle.viewmodel;

public final class R$id {
    public static final int view_tree_view_model_store_owner = 2131165352;
}
