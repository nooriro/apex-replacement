package androidx.lifecycle;

import java.util.HashMap;

public class MethodCallsLogger {
    public MethodCallsLogger() {
        new HashMap();
    }
}
