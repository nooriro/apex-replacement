package androidx.appcompat.resources;

public final class R$drawable {
    public static final int abc_vector_test = 2131099733;
}
